# البناء والإصدار

## المتطلبات المستخلصة من اللقطة

- Flutter Stable `3.35.7` كما يحدده `source/.github/workflows/flutter.yml`.
- Dart SDK ضمن `>=3.5.0 <4.0.0`.
- JDK 17.
- Android SDK platform / `compileSdk` 36؛ `targetSdk` 35؛ الحد الأدنى `minSdk` 26.
- Android Gradle Plugin `8.9.1`، Kotlin Android plugin `2.1.0`، Gradle wrapper `8.14-all`.
- اتصال الشبكة لحل حزم pub وGradle ومصادر APIs.

الإصدارات الدقيقة لحزم Dart غير مقفلة بملف `pubspec.lock` في هذه اللقطة؛ `pubspec.yaml` يحدد قيوداً نطاقية. راجع `DEPENDENCIES.md`.

## التحليل والاختبارات

من جذر التطبيق داخل الحزمة:

```bash
cd source
flutter --version
flutter pub get
flutter analyze
flutter test --reporter expanded
```

## APK محلي

تأكد من تثبيت Android SDK وضبط `local.properties` محلياً (لا تُضمّن هذا الملف في Git)، ثم:

```bash
cd source
flutter build apk --release
```

المخرج المعتاد: `build/app/outputs/flutter-apk/app-release.apk`. المسار `build/` مستثنى من Git؛ لا تنسخ APK مولداً إلى الحزمة إلا بطلب منفصل.

### توقيع APK

- `android/app/build.gradle.kts` يقرأ `android/key.properties` أو متغيرات البيئة.
- إذا لم توجد مفاتيح release، فإن `release` fallback يستخدم signing config الخاص بـdebug. هذا مناسب للاختبار فقط، وليس مفتاح نشر موثوقاً.
- لا تضع keystore أو كلمات المرور في المستودع أو هذه الحزمة. أنشئ مفتاحاً تملكه واحفظه في Secret store موثوق.
- إعداد CI يقرأ `NOVA_KEYSTORE_BASE64`, `NOVA_KEYSTORE_PASSWORD`, `NOVA_KEY_ALIAS`, و`NOVA_KEY_PASSWORD` من GitHub Secrets، ويمرر مساراً مؤقتاً عبر `NOVA_KEYSTORE_PATH`. هذه أسماء متغيرات فقط؛ لا توجد قيم أسرار فعلية هنا.

## سلوك GitHub Actions في لقطة المصدر

### `source/.github/workflows/flutter.yml`

- الاسم: Flutter Build & Delivery.
- يُشغّل عند push إلى `arena/9027d464-nova-craft` أو `main`، أو `workflow_dispatch`؛ يتجاهل تغييرات README/docs وحدها.
- يستخدم `ubuntu-24.04`, Java 17, Flutter 3.35.7، ويشغّل `flutter pub get`, `flutter analyze`, `flutter test` ثم بناء APK.
- يفحص التوقيع والمحاذاة والبصمة، يرفع artifact لمدة 30 يوماً، ثم ينشئ GitHub prerelease ويحمل الملفات إليه. لديه `contents: write`؛ تشغيله **ينشر Release فعلياً**.
- توجد خطوة إصدار مباشر قابلة للتنزيل. لا تشغّل workflow لمجرد التحقق إن لم تكن تريد نشر prerelease.

### `source/.github/workflows/android-smoke.yml`

workflow يدوي يطلب tag وglob لملف APK منشور. ينزّل artifact من Release، يفحصه، ويشغله على Android emulator في GitHub runner. هذا ليس جزءاً من إنشاء الحزمة ولا يشتغل تلقائياً مع كل build.

### `runtime-templates/.github/workflows/novacraft-server.yml`

قالب ينشئه التطبيق في repository السيرفر. يطلب `start` أو `snapshot` ويقبل `restore_tag`; يشغّل job على Ubuntu 24.04 بحد ست ساعات ويستعيد/يحفظ cache. تشغيله ينفذ خدمة Minecraft وPlayit وعمليات Releases للسيرفر، وليس build للتطبيق.

## ما لم يُنفّذ في إعداد الحزمة

لم تُشغّل أوامر Flutter أو Gradle ولم يُبنَ APK جديد؛ أدوات Flutter/Dart غير متاحة في بيئة هذه المهمة. الدليل التاريخي للـCI موضح في `SOURCE_LINEAGE.md` و`FEATURES_AND_STATUS.md`، ولا يحل محل تشغيل جديد على الجهاز أو حساب المستخدم.
