# أصل المصدر والمقارنة والاستبعادات

## الالتزامات التي فُحصت

| الدور | الالتزام | العنوان |
|---|---|---|
| المرجع المطلوب | `070385b75acc8abd3c7023ab9d74ff8dd7695bf4` | `Prepare fresh Android APK build` |
| لقطة المصدر المختارة للحزمة | `b3bf132d9a087d7f625d9564c1600d07258b0553` | `Document verified Modrinth repair release` |
| التحقق التاريخي المرتبط بالكود | `828a0218748ae8dbec016d05f79976ca67eb33ad` | سلف للالتزام المصدري المختار؛ run `39339756155` |

المرجع `070385b` سلف لـ`origin/arena/9027d464-nova-craft` الذي كان عند `b3bf132` بعد `git fetch origin`. الحزمة تستخدم snapshot أحدث من المرجع لكي تجمع الإصلاحات والاختبارات اللاحقة، ولا تدّعي أن كل ملف فيها مطابق لنسخة `070385b` حرفياً.

بين `070385b` و`b3bf132` أظهر فحص Git تغيير 32 مساراً، بنحو 4,162 إضافة و503 حذف في diff الإجمالي. من أهم الزيادات المرتبطة بوظائف طلبها المستخدم: `cancellation.dart`, `modrinth_api.dart`, `modrinth_installer.dart`, `server_file_manifest.dart`, توسعة `github_api.dart` و`workflow_templates.dart`، وملفات اختبار file operations/Modrinth/world manifests. كما تغيرت شاشات mods/files/worlds/backups/network والإعدادات. لم يُنسخ diff التقارير القديمة أو APK.

## ما أُدرج

- لقطة source محددة من `b3bf132...` تشمل `.github/workflows/`, `.gitignore`, `.metadata`, `analysis_options.yaml`, `pubspec.yaml`, Android Gradle/wrapper/native config، الأصول التي يحتاجها التطبيق، كامل `lib/` وكامل `test/`.
- `runtime-templates/` مقتطفة مباشرة من القوالب الخام في `lib/core/workflow_templates.dart`. فُحص تطابق الاستخراج من المصدر، واستُبدل `__SID__` في workflow فقط بـ`example-server-id` لتمييز القيمة المثال.
- وثائق جديدة تفرق بين الموجود والمختبر والمحدود، ولا تعيد نشر تقارير المشروع القديمة.

## ما استُبعد ولماذا

- `nova-craft-final.apk` (كان في ref كـartifact بناء كبير)، وأي APK/AAB مولّد.
- `build_log.txt`, `builds.json`, `paper.json`, `final_sha256.txt`, `sha256.txt`, `SHA256SUMS.txt` الأصلية و`smoke-trigger.txt`: سجلات/metadata/بصمات build وليست كوداً مطلوباً لإعادة الاستخدام.
- `docs/` القديمة في snapshot وتقارير إعادة البناء، والملف التنفيذي الطويل `NOVA_CRAFT_Complete_Development_Prompt_AR.md`: ليست تبعيات تشغيل، وقد تحتوي سياق مستخدم/تشخيص تاريخي أو متطلبات لم تعد تمثل الكود.
- أي `.git` history أو repository data أو server/world/backup folders أو ملفات أسرار/توقيع حقيقية.

أُدرجت أصول التطبيق الثابتة والخطوط مع ملفات ترخيص OFL لأنها لازمة للبناء. لم تُدرج بيانات مستخدم.

## حدود النسخة المصدرية

- `source/` يتكون من 138 ملفاً متتبّعاً من snapshot المختار، إضافةً إلى `source/README.md` التوضيحي الذي أُضيف للحزمة (139 ملفاً إجمالاً)، ولا يتضمن كل شجرة المشروع ولا تاريخ Git.
- `pubspec.lock` غير موجود في المصدر الأصلي المختار، لذلك الإصدارات العابرة غير مقفلة.
- شجرة العمل المحلية في `/home/user/NOVA-CRAFT` كانت متسخة وبها ملفات غير متتبعة. لم تُعدّل أو تُنظّف أو تُستبدل؛ استُخدمت Git refs الثابتة لإنتاج الحزمة. لذلك قد لا تتضمن الحزمة أي تعديل محلي غير ملتزم به.
- لم يُبنَ التطبيق ولم تُشغّل اختبارات Flutter لهذه الحزمة، لعدم توفر `flutter`/`dart` في البيئة الحالية. تم فحص نحو shell/Python للسكربتات المستخرجة وسلامة الأرشيف، كما يسجل جدول الأدلة في `FEATURES_AND_STATUS.md` نتيجة CI تاريخية على commit سلف.

## دليل CI التاريخي

تذكر سجلات العمل السابقة نجاح GitHub Actions run [39339756155](https://github.com/abiedadam0077/NOVA-CRAFT/actions/runs/39339756155) على `828a021...`، وهو سلف للنسخة المصدريّة. شمل التقرير التحليل والاختبارات وبناء APK وفحوص التوقيع والمحاذاة وSHA-256 ونشر prerelease. هذا دليل تاريخي للكود على ذلك الالتزام، وليس إعادة تحقق لهذا الـZIP ولا اختباراً على هاتف فعلي.
