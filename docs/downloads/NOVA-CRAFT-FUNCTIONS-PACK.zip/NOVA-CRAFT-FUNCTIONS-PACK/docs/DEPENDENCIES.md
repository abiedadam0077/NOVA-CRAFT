# الاعتماديات ومتطلبات التشغيل

## Flutter / Dart

القيود أدناه من `source/pubspec.yaml` في commit `b3bf132...`. لا يوجد `pubspec.lock` في هذه اللقطة، ولذلك لا يمكن تثبيت إصدارات transitive الدقيقة من ملفات الحزمة وحدها.

| الحزمة | القيد في `pubspec.yaml` | الاستخدام الظاهر في المصدر |
|---|---:|---|
| `flutter` | SDK | الواجهات، الحالة والـwidgets. |
| `flutter_localizations` | SDK | دعم locale للنصوص والواجهة. |
| `http` | `^1.5.0` | REST والتحميل المتدفق لـGitHub/Minecraft/Modrinth/Playit. |
| `crypto` | `^3.0.6` | hashes محلية، منها SHA-256 لملفات Modrinth. |
| `shared_preferences` | `^2.3.3` | تفضيلات غير سرية مثل اللغة والمظهر. |
| `flutter_secure_storage` | `^9.2.2` | تخزين token وPlayit secret محلياً عبر secure storage. |
| `url_launcher` | `^6.3.1` | فتح صفحات GitHub/Playit وروابط Releases خارجياً. |
| `file_picker` | `^8.1.6` | اختيار ملفات JAR والعوالم والـBedrock packs من الجهاز. |
| `archive` | `^3.6.1` | فك/قراءة أرشيفات ZIP، ومنها سجلات Actions. |
| `pinenacl` | `^0.6.0` | sealed-box encryption لكتابة Actions Secret إلى GitHub. |
| `flutter_test` | SDK (dev) | اختبارات unit/widget. |
| `flutter_lints` | `^5.0.0` | قواعد lint. |

## Android وGradle

- Flutter Stable `3.35.7` وJDK 17 كما في CI.
- Gradle wrapper `8.14-all` (`android/gradle/wrapper/gradle-wrapper.properties`).
- Android Gradle Plugin `8.9.1` وKotlin plugin `2.1.0` (`android/settings.gradle.kts`).
- `compileSdk = 36`, `targetSdk = 35`, `minSdk = 26`, JVM target 17.
- AndroidX Core KTX `1.13.1` في `android/app/build.gradle.kts`.
- بناء محلي يحتاج Android SDK، platform 36، build-tools، و`android/local.properties` محلياً. لا توجد قيم local.properties في الحزمة.

## أدوات workflow والسيرفر

- GitHub Actions runners: `ubuntu-24.04`.
- أدوات مستخدمة من runner: Bash، Python 3 القياسي، Java الذي يجهزه `actions/setup-java`, `gh`, `curl`, `jq`, `zip/unzip`, `sha256sum`, `timeout` وأدوات shell/الضغط المعتادة في صورة GitHub.
- لا توجد requirements.txt؛ السكربتات المولدة تعتمد Python standard library.
- Playit Agent Linux AMD64: `v1.0.10` مع SHA-256 ثابت في كود runner؛ يُنزّل وقت التنفيذ ولا يوجد binary داخل الحزمة.
- Minecraft downloads وAPIs: Mojang, Paper Fill v3, Purpur, Fabric Meta، ورابط Bedrock الرسمي المستخدم في الكود.
- Modrinth: `api.modrinth.com/v2` وCDN المحدد من response بعد فحص URI.
- GitHub API: `api.github.com`; Playit Agent API: `api.playit.gg`.

## GitHub Actions المستخدمة في الملفات

تظهر tags التالية في YAML الحالي: `actions/checkout@v4`, `actions/setup-java@v4`, `actions/cache/restore@v4`, `actions/cache/save@v4`, و`actions/upload-artifact@v4`; يستخدم workflow البناء أيضاً Flutter action `subosito/flutter-action@v2`. راجع workflow قبل النقل إلى مستودع آخر وتحقق من الإصدارات/permissions في وقت الاستخدام.
