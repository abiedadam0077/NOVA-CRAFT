# الوظائف الموجودة وحالتها وحدودها

## طريقة قراءة الحالة

- **موجود بالكود**: توجد مسارات تنفيذ فعلية في اللقطة، وليس مجرد نص تصميم.
- **اختبارات آلية**: يوجد اختبار unit/contract أو runner harness مناسب؛ لا يعني ذلك تجربة كل حساب/سيرفر إنتاجي.
- **دليل CI تاريخي**: يوجد workflow ناجح لالتزام سلف من لقطة المصدر، لكنه لم يُعَد تشغيله لهذه الحزمة.
- **محدود/غير موجود**: قيد مستخلص من الكود الحالي، ويجب عدم تسويقه كوظيفة مكتملة.

## جرد الوظائف

| المجال | ما يوجد فعلاً | الاختبارات/الحدود |
|---|---|---|
| GitHub login | OAuth Device Flow، polling/refresh، تخزين token عبر secure storage، قراءة المستخدم. | `github_api_test.dart`; يتطلب إعداد GitHub App/صلاحيات repository في حساب المستخدم. لا توجد أسرار GitHub خاصة داخل الحزمة. |
| المستودعات وActions | إنشاء/اختيار repo، التحقق من صلاحية الكتابة وتثبيت App، قراءة الملفات، رفع/حذف، dispatch، runs/jobs/logs، cancel/rerun. | اختبارات API بعينات. workflow يتطلب `contents: write` و`actions: write`، وكتابة secret تتطلب صلاحية secrets المناسبة. |
| إنشاء Java | Vanilla وPaper وPurpur وFabric، قائمة إصدارات من مصادرها، حل رابط البناء وJava major، تخزين checksum عند توفره. | `minecraft_test.dart`. اختيار Forge وNeoForge معطّل، وSpigot ليس خيار إنشاء في الـwizard. فحص checksum يتوقف على ما يقدمه المصدر؛ Bedrock لا يوفّر hash في هذا الكود. |
| إنشاء Bedrock | Bedrock Dedicated Server (BDS) من رابط Linux الرسمي الأحدث الذي يُحل وقت التشغيل. | `minecraft_test.dart` وملفات runner. يوجد **الإصدار الأحدث فقط**؛ لا يوجد اختيار تاريخي/تثبيت إصدار محدد في الـwizard، ولا checksum مصدره متاح في resolver. |
| تشغيل/إيقاف/إعادة تشغيل | GitHub Actions workflow يدوي، أوامر queue للإيقاف والـbackup، restart بعد تسلسل stop ثم dispatch. | اختبارات runner/contract. دورة job مؤقتة: 5 ساعات للـserver ضمن 6 ساعات للـjob، وليست استضافة دائمة. |
| Playit | إدخال Agent secret يدوياً، فحص قائمة tunnels، اختيار tunnel متوافق؛ تخزين محلي آمن، وكتابة `PLAYIT_SECRET_KEY` في repo مشفّراً. Runner يبدأ Agent بعد ping محلي ويتحقق من Java TCP أو Bedrock UDP. | `playit_api_test.dart`, `playit_runner_test.dart`, `playit_runner_integration_test.dart`. لا يوجد OAuth لـPlayit ولا إنشاء tunnel آلي؛ يحتاج tunnel جاهزاً من المستخدم. لا يُعرض address إلا إذا أبلغ به Playit. |
| Mods وPlugins | Modrinth search/version، توافق loader وMinecraft version، تنزيل متدفق مع cancellation/retry/hash/size check، رفع JAR والتحقق من blob في repo؛ رفع/حذف JAR محلي. | `modrinth_test.dart`, `modrinth_installer_test.dart`. Modrinth فقط، وحد تنزيل 45 MiB. Mods لـFabric، Plugins لـPaper/Purpur (وتوجد predicate لـSpigot في model لكنه ليس خيار إنشاء). لا دعم ظاهر لـCurseForge أو Forge/NeoForge. توافق metadata لا يضمن تشغيل الإضافة فعلياً. |
| Bedrock add-ons | رفع `.mcaddon`/`.mcpack`، تفعيل/تعطيل وإزالة، وربط الحزم بالعالم الذي اختاره المستخدم. | قوالب `fileops.py` تراجع manifests وتطبّق packs؛ ليس متجراً ولا فحص توافق شامل للمحتوى. الرفع من الواجهة محدود تقريباً بـ45 MiB. |
| الملفات | manifest حقيقي من مجلد بيانات السيرفر؛ استعراض، تحرير ملفات نصية، رفع، إنشاء مجلد، إعادة تسمية وحذف عبر عمليات آمنة داخل جذر البيانات. يمكن حفظ snapshot عند توقف السيرفر، ويطبق runner الكتابة. | `files_screen_test.dart`, `fileops_integration_test.dart`, `worlds_manifest_test.dart`. الرفع العام في شاشة Files محدود بـ20 MiB؛ الملفات الثنائية لا تُحرر كنص ولا يوجد تنزيل مستقل عام لكل ملف من هذه الشاشة. المسارات تُرفض إذا خرجت عن الجذر. |
| Console | قراءة tail حقيقي للسجل أثناء التشغيل، أو log archive بعد انتهاء run، وأوامر عبر queue. تحديث polling وليس WebSocket. | `runner_contract_test.dart`, `validation_test.dart`. الحد الأقصى للأمر 512 محرفاً؛ محارف التحكم مرفوضة؛ الأوامر الخطرة تتطلب تأكيداً و`nova:` محجوز للنظام. |
| الإعدادات | Java/Bedrock `server.properties` وبعض config: الاسم/MOTD، max players، gamemode، difficulty، المسافات، PvP/whitelist/online-mode/seed، الذاكرة، EULA، الأوامر، AutoRestart والاحتفاظ بالنسخ. الذاكرة تُستخدم كـ`-Xmx`. | `models_test.dart`, `validation_test.dart`. ليست كل خصائص Minecraft موجودة؛ لا Java flags شاملة ولا RCON configuration أو تحكم كامل في كل نوع سيرفر. |
| Worlds | اكتشاف العوالم من manifest (`level.dat` ومعايير Bedrock)، إظهار الحجم والملفات، استيراد ZIP، فحص archive، backup حماية قبل استبدال العالم، وفتح رابط backup للتنزيل. | `worlds_manifest_test.dart`, `fileops_integration_test.dart`. رفع ZIP من شاشة Worlds محدود بـ40 MiB؛ تنزيل العالم يتم عبر archive/backup كامل من GitHub Release، لا تنزيل world فرعي من داخل التطبيق. |
| Backups | يدوي، on-demand أثناء دورة السيرفر، وbackup عند نهاية كل دورة؛ ZIP + SHA-256 + إعادة تنزيل/تحقق قبل وضع علامة verified؛ restore/delete/retention. | التنفيذ في runner و`backups_screen.dart`. حد ملف Release 2 GiB في runner، والاحتفاظ مضبوط بين 2 و30. Actions cache تحسين استعادة وليس نسخة دائمة. تنزيل الواجهة يفتح رابط GitHub خارجياً. |
| اللاعبين | عدد اللاعبين الحالي/الحد الأقصى من ping أو log عند توافره. يمكن إرسال أوامر Minecraft عبر Console، ومنها whitelist/ban/op مع تأكيدات الأوامر الخطرة. | **لا توجد شاشة أو CRUD مستقل لقائمة اللاعبين**، ولا مصدر ثابت لقائمة online players في التطبيق. لا تدّعِ إدارة لاعبين كاملة. |
| الحالة والموارد | runner يكتب phase/heartbeat؛ التطبيق يميّز حالة workflow عن جاهزية السيرفر ويتحقق من freshness، ويجري ping بروتوكولياً. RSS لعملية السيرفر قد يظهر. | لا يوجد CPU؛ RAM المعروضة RSS للعملية وليست إجمالي ذاكرة الجهاز. إذا غابت heartbeat/ping لا يجب اختلاق القيمة. |
| الجدولة/إعادة التشغيل | `autoRestart` يرسل دورة workflow جديدة عند نهاية دورة الخمس ساعات ما لم يطلب المستخدم stop. كل دورة تحفظ backup عند الإنهاء. | **لا يوجد cron أو اختيار وقت يومي/أسبوعي للنسخ الاحتياطي/إعادة التشغيل**. التكرار يستهلك GitHub Actions minutes وقد ينشئ Releases دورية. |
| اللغة/التفضيلات | نصوص عربية وإنجليزية، تفضيلات theme/language وإشعارات محلية. | `strings_test.dart`, `widget_test.dart`; لا يعني ذلك اختباراً بصرياً على كل أحجام الأجهزة. |
| Geyser | لا يوجد Geyser-specific integration متميّز في طبقة الخدمات الحالية. تظهر Geyser كبيانات fixture ضمن اختبار generic لمثبت Modrinth. | **لم يتغير منطق Geyser ولم يُجرَ إصلاح له** أثناء استخراج الحزمة، امتثالاً لطلب المستخدم. لا نستنتج دعماً خاصاً لـGeyser من fixture اختبار. |

## ملفات الاختبار الـ17

`fileops_integration_test.dart`, `files_screen_test.dart`, `formatters_test.dart`, `github_api_test.dart`, `minecraft_test.dart`, `models_test.dart`, `modrinth_installer_test.dart`, `modrinth_test.dart`, `playit_api_test.dart`, `playit_runner_integration_test.dart`, `playit_runner_test.dart`, `runner_contract_test.dart`, `scripts_contract_test.dart`, `strings_test.dart`, `validation_test.dart`, `widget_test.dart`, `worlds_manifest_test.dart`.

## ما تم التحقق منه وما لم يتم

- المصدر يتضمن اختبارات offline/mocks/fixtures وعقوداً للـworkflow والـrunner.
- تاريخياً نجح GitHub Actions run `39339756155` على الالتزام `828a0218748ae8dbec016d05f79976ca67eb33ad`، وهو سلف لقطة المصدر. التقرير السابق سجّل نجاح التحليل، الاختبارات، بناء APK، فحوص التوقيع والمحاذاة وSHA-256 ونشر prerelease. [سجل التشغيل](https://github.com/abiedadam0077/NOVA-CRAFT/actions/runs/39339756155).
- لم يُشغَّل `flutter analyze` أو `flutter test` أو build من بيئة إعداد الحزمة الحالية؛ Flutter/Dart غير مثبتين فيها. فُحصت سلامة ZIP وقوالب runner المستخرجة (Bash syntax وPython AST) محلياً فقط.
- لا يوجد دليل هنا على تشغيل سيرفر فعلي أو فحص هاتف Android فعلي في هذه المهمة. الرجاء التمييز بين test harness، CI سابق، وتشغيل إنتاجي.
