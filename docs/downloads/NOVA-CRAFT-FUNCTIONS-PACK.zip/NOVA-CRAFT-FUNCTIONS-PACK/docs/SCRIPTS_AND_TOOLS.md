# السكربتات والأدوات والـworkflows

## مصدر السكربتات

السكربتات التي تشغّل السيرفر مضمّنة في `source/lib/core/workflow_templates.dart` كسلاسل Dart خام. `Provisioner.writeServerFiles` يرفعها إلى مستودع السيرفر. أُخرجت منها نسخ مستقلة مطابقة تحت `runtime-templates/`؛ لم تُكتب من جديد ولم يُغيّر منطقها.

| المسار في الحزمة | القالب/المصدر | المسؤولية الفعلية |
|---|---|---|
| `runtime-templates/.github/workflows/novacraft-server.yml` | `_serverWorkflow` | workflow يدوي بمدخل `start` أو `snapshot`، ومدخل restore اختياري، وcache للبيانات، وحد job ست ساعات، وصلاحيات `contents` و`actions` للكتابة. قيمة server ID في هذه النسخة مثال فقط. |
| `runtime-templates/nova-craft/config.py` | `WorkflowTemplates.configScript` | قراءة `server.json`، رفض `dataPath` غير الآمن، إخراج قيم GitHub Actions، وإعادة كتابة خصائص السيرفر/EULA من الإعدادات. |
| `runtime-templates/nova-craft/runner.sh` | `WorkflowTemplates.runnerScript` | جلب البيانات/البناء، التحقق المتاح من الهاش، استعادة أو إنشاء backup، تشغيل السيرفر، Playit، نشر الحالة والسجل والـmanifest، معالجة الأوامر والعمليات، الإيقاف الآمن وإطلاق الدورة التالية إذا فُعّل ذلك. |
| `runtime-templates/nova-craft/playit.py` | `WorkflowTemplates.playitScript` | تحليل rundata، تحديد tunnel متوافق أو طلب اختيار صريح، واختبار Java TCP / Bedrock UDP بالبروتوكول المناسب. لا ينشئ tunnels. |
| `runtime-templates/nova-craft/fileops.py` | `WorkflowTemplates.fileOpsScript` | جذر بيانات آمن، manifest، list/read/write/mkdir/rename/delete، snapshots، التحقق من ZIP واستيراد العوالم، تطبيق Bedrock packs، ومزامنة JARs المدارة. |

`WorkflowTemplates.javaProperties` و`bedrockProperties` يولّدان `server.properties` حسب إعداد `ServerConfig`. لا تُرفق الحزمة إعداد سيرفر فعلياً أو `server.json` خاصاً بمستخدم.

## ما يفعله الـrunner بالترتيب العام

1. يتحقق من `dataPath` ويرفض المسارات المطلقة، `..`، الروابط الرمزية وبعض مجلدات repository الخاصة.
2. يستعيد cache والـsnapshot المدارة، ويعالج restore tag عند الطلب بعد التحقق من backup.
3. يتحقق من ملف world ZIP قبل الاستبدال. إذا وُجد عالم سابق، ينشئ backup حماية موثقاً أولاً؛ يرفض الاستبدال إذا تعذّر ذلك.
4. يطبّق uploads وBedrock add-ons ويتحقق من ملفات JAR المدارة ووجهتها، ثم ينزّل build Java أو Bedrock ويشغّله.
5. لا يبدأ Playit قبل استجابة منفذ Minecraft المحلي. ينزّل Playit Agent بإصدار محدد وبصمة SHA-256 محددة في المصدر، ويرفض binary غير المطابق.
6. ينشر status وlog tail وmanifest، ويعيد فحص حالة Agent/tunnel. لا يعتبر عنواناً عاماً صالحاً لمجرد وجوده؛ يجري ping خاصاً ببروتوكول Minecraft.
7. أثناء التشغيل يقرأ queue الأوامر والعمليات، ويعالج backup يدوي، ثم عند الإنهاء يطلب حفظ اللعبة، يحقق backup، يوقف السيرفر وAgent، وقد يطلق الدورة التالية.

تفاصيل الحدود الزمنية والـcache وملفات الحالة موثقة أيضاً في `PROJECT_ARCHITECTURE.md` و`FEATURES_AND_STATUS.md`.

## أدوات GitHub وAndroid

### GitHub API من التطبيق

`source/lib/core/github_api.dart` ينفذ، حسب مسارات الكود:

- OAuth Device Flow وrefresh token، وقراءة المستخدم.
- جلب GitHub App installations وrepos المسموح بها وإنشاء repository.
- listing/reading/writing/deleting محتوى repository، واستخدام Git Data API للرفع الأكبر حيث يلزم.
- dispatch لـworkflow، قراءة runs/jobs/logs، cancel/rerun.
- قراءة/إنشاء/حذف Releases وتنزيل assets.
- تشفير repository Actions Secret بالمفتاح العام عبر sealed box ثم التحقق من ظهوره بالقائمة.

### خدمات خارجية مذكورة في المصدر

- GitHub REST API: `api.github.com`.
- Mojang Java version manifest وmetadata، Paper Fill v3، Purpur API، Fabric Meta، وروابط تنزيل Bedrock الرسمية التي يستخدمها الكود.
- Modrinth v2 API/CDN للبحث والإصدارات والملفات.
- Playit Agent API `POST /v1/agents/rundata`؛ السر يُرسل في Authorization ولا يُطبع بالسجلات.
- Playit Linux daemon بإصدار `v1.0.10` وبصمة SHA-256 محددة في `runner.sh`.

### GitHub Actions الموجودة في مشروع التطبيق

- `source/.github/workflows/flutter.yml`: تحليل واختبارات Flutter، بناء APK، فحوص التوقيع والمحاذاة والـSHA-256، رفع artifact ثم إنشاء prerelease قابل للتنزيل.
- `source/.github/workflows/android-smoke.yml`: يدوي؛ ينزّل APK منشوراً، يتحقق منه ويثبته على emulator في runner.
- `runtime-templates/.github/workflows/novacraft-server.yml`: قالب منفصل ينشئه التطبيق لكل سيرفر.

الـworkflows الثلاثة لها آثار فعلية على GitHub عند تشغيلها؛ لا تشغّلها على repository حقيقي قبل قراءة `BUILD_AND_RELEASE.md`.

## الأدوات المطلوبة للتشغيل داخل runner

الـworkflow يحدد `ubuntu-24.04` ويعتمد على أدوات صورة GitHub-hosted المعتادة، منها Bash، Python 3، Java، GitHub CLI `gh`، `curl`، أدوات الضغط/فك الضغط، `jq`، `sha256sum`، `timeout` وGNU coreutils. يستخدم Actions من المستودعات الرسمية المحددة في YAML مثل checkout/setup-java/cache. لا توجد حزمة Python خارجية ضمن السكربتات المضمّنة؛ تستخدم مكتبة Python القياسية.

إعدادات البناء والأدوات المحلية للـFlutter مفصلة في `DEPENDENCIES.md`.

## الاختبارات المضمّنة

يوجد 17 ملف اختبار تحت `source/test/`. من أهمها:

- `github_api_test.dart`: تدفق API والرفع.
- `minecraft_test.dart`: resolvers والإصدارات.
- `modrinth_test.dart`, `modrinth_installer_test.dart`: search/compatibility والتنزيل والتحقق والرفع.
- `playit_api_test.dart`, `playit_runner_test.dart`, `playit_runner_integration_test.dart`: parsing/diagnostics وسلوك runner مع fixtures.
- `fileops_integration_test.dart`, `worlds_manifest_test.dart`: المسارات والـmanifest واستيراد العوالم.
- `runner_contract_test.dart`, `scripts_contract_test.dart`: عقود ومحتوى القوالب.

هذه الاختبارات لا تعني أن كل تكامل اختُبر ضد حساب GitHub أو Playit إنتاجي؛ راجع `FEATURES_AND_STATUS.md` لمستوى الدليل.
