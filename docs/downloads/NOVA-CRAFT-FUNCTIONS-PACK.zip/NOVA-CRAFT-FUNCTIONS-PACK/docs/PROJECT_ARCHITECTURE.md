# بنية المشروع وتدفق الوظائف

## نظرة عامة

NOVA CRAFT تطبيق Flutter على Android، يتواصل من الجهاز مباشرةً مع GitHub وواجهات Minecraft وModrinth وPlayit. لا يوجد backend خاص بالتطبيق في هذه اللقطة. تشغيل Minecraft يحصل داخل GitHub Actions runner مؤقت، وليس على خادم دائم تديره الحزمة.

```text
شاشات Flutter
  ├─ AppState / SecureStore ── جلسة GitHub والإعدادات المحلية
  ├─ GitHubApi ─────────────── GitHub REST API / محتوى المستودع / Actions / Releases / Secrets
  ├─ MinecraftApi ──────────── Mojang / Paper / Purpur / Fabric / Bedrock download metadata
  ├─ ModrinthApi + Installer ─ البحث والتنزيل والتحقق ثم رفع JAR إلى المستودع
  └─ PlayitApi ─────────────── حالة Agent والـtunnels
                    │
             Provisioner + WorkflowTemplates
                    │ يكتبان إعدادات السيرفر وقوالب التنفيذ في مستودع المستخدم
                    ▼
          GitHub Actions: ubuntu-24.04 (وظيفة مؤقتة)
             ├─ runner.sh ─ تنزيل/تشغيل Java أو Bedrock، حالة، console، backups
             ├─ playit.py + Playit Agent ─ حالة الاتصال والـtunnel
             └─ fileops.py ─ ملفات السيرفر والعوالم والـaddons
                    │
                    ├─ status.json / live.log / files/manifest.json
                    ├─ GitHub Actions cache (استعادة سريعة وليست مخزناً دائماً)
                    └─ GitHub Releases (نسخ احتياطية موثّقة)
                              │
                              └─ التطبيق يقرأ الحالة والسجلات ويجري ping بروتوكولياً
```

## طبقات المصدر

### 1. نقطة الدخول والواجهة

- `source/lib/main.dart`, `source/lib/app.dart`: تهيئة التطبيق وMaterialApp.
- `source/lib/features/`: المصادقة، اختيار المستودع، إنشاء السيرفر، الصفحة الرئيسية، الكونسول، الملفات، mods/add-ons، الشبكة، Worlds، Backups، الإعدادات والحساب.
- `source/lib/design/`: theme وtokens والـwidgets. هذه ملفات الواجهة الأصلية؛ لم تُعدّل في الحزمة.
- التنقل الرئيسي في `features/shell/app_shell.dart`، والميزات الأخرى صفحات فرعية.

### 2. الحالة والتخزين المحلي

- `state/app_state.dart`: جلسة GitHub، اختيار السيرفر، إعدادات اللغة/المظهر، Playit وحالة repositories.
- `state/server_monitor.dart`: polling لـActions runs/jobs و`nova-craft/status.json` و`live.log`، وطلب ping Java/Bedrock.
- `core/secure_store.dart`: GitHub access/refresh tokens ومفتاح Playit عبر `flutter_secure_storage`؛ التفضيلات غير السرية في `SharedPreferences`.

### 3. الخدمات والنماذج

- `core/github_api.dart`: Device Flow، المستخدم والمستودعات، محتوى الملفات، رفع الملفات، workflow dispatch/runs/logs، Releases وActions Secrets.
- `core/minecraft_api.dart`, `minecraft_ping.dart`: اكتشاف إصدارات وتنزيلات Java/Bedrock وJava/Bedrock protocol ping.
- `core/modrinth_api.dart`, `modrinth_installer.dart`: بحث Modrinth، توافق loader/version، تنزيل مع التحقق من الحجم والهاش، ثم تحقق من كتابة JAR في المستودع.
- `core/playit_api.dart`: قراءة بيانات Agent/tunnels واختيار tunnel متوافق مع Edition والبروتوكول.
- `core/models.dart`, `validation.dart`, `server_file_manifest.dart`, `cancellation.dart`, `logs.dart`, `formatters.dart`: النماذج والتحقق والتنسيق وإلغاء العمليات.

### 4. إنشاء ملفات السيرفر وتشغيلها

`core/provisioner.dart` ينسّق الكتابة والـworkflow dispatch. القوالب التنفيذية نفسها داخل `core/workflow_templates.dart`، وليس في مجلد scripts مستقل ضمن التطبيق. هذه القوالب تُرفع إلى مستودع السيرفر تحت `nova-craft/`، ومنها `runner.sh`, `config.py`, `playit.py`, `fileops.py` و`.github/workflows/novacraft-server.yml`.

نسخ مستقلة مطابقة للقوالب موجودة تحت `runtime-templates/` لتسهيل مراجعتها وإعادة استخدامها. ملف الـworkflow فيها يستخدم `example-server-id` كقيمة توضيحية بدلاً من قيمة السيرفر الحقيقية.

### 5. فصل كود التطبيق عن بيانات السيرفر

المشروع الذي داخل `source/` هو **كود التطبيق**. عند إنشاء سيرفر، يكتب التطبيق ملفات تشغيل/إعداد إلى repository يختاره المستخدم. بيانات Minecraft الحية تكون تحت `ServerConfig.dataPath` (افتراضياً `server/`) في مساحة عمل الـrunner، وتُدار عبر manifest وطلبات file operations؛ ليست جزءاً من ملفات المصدر المضمّنة في ZIP.

الـworkflow يستخدم Actions cache لاستعادة مجلد البيانات بين الدورات، لكنه ينشر أيضاً النسخة الاحتياطية في Release لأن cache قابل للإخلاء. النسخ التي يكتشفها التطبيق موسومة ومتحقق منها عبر SHA-256 وملف `world-backup.sha256` وعلامة توثيق في Release.

## دورة إنشاء وتشغيل مختصرة

1. المستخدم يربط GitHub عبر Device Flow، ويختار repository أو ينشئ واحداً.
2. التطبيق يتحقق من صلاحية الكتابة ومن تثبيت GitHub App على repository المختار.
3. `MinecraftApi` يحلّ رابط بناء السيرفر والهاش المتاح، ثم `Provisioner.writeServerFiles` يكتب config وworkflow والـrunner و`server.properties`، و`eula.txt` فقط بعد الموافقة الصريحة.
4. عند تفعيل Playit، يرفع التطبيق السر إلى Actions Secrets باسم `PLAYIT_SECRET_KEY` مشفّراً بمفتاح repository العام؛ لا يضع السر داخل `server.json`.
5. يبدأ workflow يدوياً (`workflow_dispatch`). يعمل runner حتى خمس ساعات كحد أقصى ضمن job limit ست ساعات، ويحمّل بيانات السيرفر ويبدأ العملية.
6. ينشر runner status وlog وmanifest، بينما التطبيق يحدّث العرض بالـpolling ويجري ping بروتوكول Minecraft للتحقق من الاتصال.
7. عند الإنهاء، يحاول runner حفظ العالم والتحقق من backup؛ ومع `autoRestart=true` يطلق دورة workflow جديدة بدلاً من جدول cron.

## حدود المعمارية

- لا يوجد اتصال WebSocket/console مباشر؛ تحديث الحالة والسجل polling عبر GitHub، والأوامر queue في ملفات repository.
- GitHub-hosted runner مؤقت ومحدود المدة؛ هذا النمط ليس دليلاً على استضافة دائمة أو SLA.
- القياسات: يعرض الكود RSS لعملية السيرفر عند وصول heartbeat حديث؛ لا يقيس CPU، ولا إجمالي RAM موثوقاً للآلة.
- صفحة اللاعبين ليست إدارة مستقلة؛ الموجود تعداد تقريبي للمتصلين من protocol ping أو log، وأوامر الإدارة تمر بالكونسول.
- لا يوجد كود Geyser خاص في طبقة الخدمات؛ الحزمة تحفظ الكود كما هو ولا تغيّر منطق Geyser.
