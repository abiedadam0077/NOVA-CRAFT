
#!/usr/bin/env python3
"""NOVA CRAFT server file operations.

Runs on the GitHub runner, inside/below the server data folder ONLY.
Every path is resolved and checked against the data root; anything that
escapes it is rejected (no traversal, no symlink escape).

Modes
  manifest <root> <out.json>
  request  <root> <request.json> <response.json>
  addons   <data_root> <addons_dir> <state.json> <out.json>
  validate-import <data_root> <zip> <world_name> <out.json> <JAVA|BEDROCK>
  import   <data_root> <zip> <world_name> <out.json> <JAVA|BEDROCK>
  sync-jars <data_root> <repo_root> <data_rel> <software> <out.json>
"""
import base64
import hashlib
import json
import os
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

MAX_READ = 700 * 1024
MAX_MANIFEST_ENTRIES = 4000
MAX_MANAGED_JAR_BYTES = 100 * 1024 * 1024
MAX_MANAGED_JARS = 1000
MAX_WORLD_ARCHIVE_ENTRIES = 100000
MAX_WORLD_FILE_BYTES = 4 * 1024 * 1024 * 1024
MAX_WORLD_ARCHIVE_BYTES = 8 * 1024 * 1024 * 1024
SKIP_DIRS = {"libraries", "versions", ".fabric", "cache", ".cache", "tmp", "crash-reports", ".nova-managed", ".nova-import-stage"}


def safe_data_root(root):
    root_abs = os.path.abspath(root)
    if os.path.islink(root_abs) or not os.path.isdir(root_abs):
        raise ValueError("unsafe data root")
    root_real = os.path.realpath(root_abs)
    if not os.path.isdir(root_real):
        raise ValueError("unsafe data root")
    return root_real


def safe_path(root, rel):
    root_real = safe_data_root(root)
    if rel is None or rel == "":
        return root_real
    if not isinstance(rel, str) or rel != rel.strip():
        raise ValueError("path-outside-root")
    normalized = rel.replace("\\", "/")
    if normalized == ".":
        return root_real
    parts = normalized.split("/")
    if (normalized.startswith("/") or any(part in ("", ".", "..") for part in parts)
            or re.match(r"^[A-Za-z]:", parts[0])):
        raise ValueError("path-outside-root")
    candidate = os.path.realpath(os.path.join(root_real, *parts))
    if candidate != root_real and not candidate.startswith(root_real + os.sep):
        raise ValueError("path-outside-root")
    return candidate


def manifest(root):
    root_real = safe_data_root(root)
    files = []
    dirs = []
    truncated = False
    for dirpath, dirnames, filenames in os.walk(root_real, followlinks=False):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not os.path.islink(os.path.join(dirpath, d))]
        rel_dir = os.path.relpath(dirpath, root_real).replace(os.sep, "/")
        if rel_dir != ".":
            dirs.append(rel_dir)
        for name in filenames:
            full = os.path.join(dirpath, name)
            if os.path.islink(full):
                continue
            try:
                st = os.stat(full)
            except OSError:
                continue
            rel = os.path.relpath(full, root_real).replace(os.sep, "/")
            files.append({"path": rel, "size": st.st_size, "modified": int(st.st_mtime)})
            if len(files) >= MAX_MANIFEST_ENTRIES:
                truncated = True
                break
        if truncated:
            break
    files.sort(key=lambda f: f["path"])
    dirs.sort()
    return {
        "schema": 1,
        "generatedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "files": files,
        "dirs": dirs,
        "truncated": truncated,
    }


def _ok(**kwargs):
    out = {"ok": True}
    out.update(kwargs)
    return out


def _fail(code):
    return {"ok": False, "error": code}


def atomic_write_bytes(path, data):
    parent = os.path.dirname(os.path.abspath(path))
    os.makedirs(parent, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".nova-craft-", dir=parent)
    try:
        with os.fdopen(fd, "wb") as handle_file:
            handle_file.write(data)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def atomic_write_json(path, payload):
    data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    atomic_write_bytes(path, data)


def handle(root, request):
    op = (request.get("op") or "").lower()
    if op == "list":
        target = safe_path(root, request.get("path") or ".")
        if not os.path.isdir(target):
            return _fail("not-a-directory")
        rel_base = os.path.relpath(target, os.path.realpath(root)).replace(os.sep, "/")
        if rel_base == ".":
            rel_base = ""
        entries = []
        for name in sorted(os.listdir(target)):
            full = os.path.join(target, name)
            if os.path.islink(full):
                continue
            st = os.stat(full)
            entries.append({
                "name": name,
                "path": (rel_base + "/" + name).lstrip("/"),
                "dir": os.path.isdir(full),
                "size": 0 if os.path.isdir(full) else st.st_size,
                "modified": int(st.st_mtime),
            })
        return _ok(path=rel_base, files=entries)
    if op == "read":
        target = safe_path(root, request.get("path") or "")
        if not os.path.isfile(target):
            return _fail("not-a-file")
        size = os.path.getsize(target)
        with open(target, "rb") as handle_file:
            data = handle_file.read(MAX_READ)
        return _ok(
            path=os.path.relpath(target, os.path.realpath(root)).replace(os.sep, "/"),
            size=size,
            truncated=size > len(data),
            content=base64.b64encode(data).decode(),
        )
    if op == "write":
        target = safe_path(root, request.get("path") or "")
        if not request.get("path"):
            return _fail("missing-path")
        data = base64.b64decode(request.get("content") or "")
        if len(data) > 2 * 1024 * 1024:
            return _fail("too-large")
        os.makedirs(os.path.dirname(target) or os.path.realpath(root), exist_ok=True)
        # A fixed sibling temporary name could be pre-created as a symlink to
        # a file outside the server data root. mkstemp uses O_EXCL and a random
        # name, then replace atomically installs the new file.
        atomic_write_bytes(target, data)
        return _ok(path=os.path.relpath(target, os.path.realpath(root)).replace(os.sep, "/"), size=len(data))
    if op == "mkdir":
        target = safe_path(root, request.get("path") or "")
        if not request.get("path"):
            return _fail("missing-path")
        os.makedirs(target, exist_ok=True)
        return _ok(path=request.get("path"))
    if op == "rename":
        src = safe_path(root, request.get("path") or "")
        dest = safe_path(root, request.get("dest") or "")
        if not request.get("path") or not request.get("dest"):
            return _fail("missing-path")
        if not os.path.exists(src):
            return _fail("not-found")
        if os.path.exists(dest):
            return _fail("destination-exists")
        os.makedirs(os.path.dirname(dest) or root, exist_ok=True)
        os.replace(src, dest)
        return _ok(path=request.get("dest"))
    if op == "delete":
        target = safe_path(root, request.get("path") or "")
        if not request.get("path"):
            return _fail("missing-path")
        if os.path.isdir(target):
            shutil.rmtree(target)
        elif os.path.exists(target):
            os.remove(target)
        else:
            return _fail("not-found")
        return _ok(path=request.get("path"))
    return _fail("unknown-op")


def _validated_zip_members(zf):
    infos = zf.infolist()
    if len(infos) > MAX_WORLD_ARCHIVE_ENTRIES:
        raise ValueError("archive-has-too-many-entries")
    result = []
    seen = set()
    total_size = 0
    for info in infos:
        raw = info.filename.replace("\\", "/")
        while raw.startswith("./"):
            raw = raw[2:]
        is_dir = info.is_dir() or raw.endswith("/")
        normalized = raw.rstrip("/") if is_dir else raw
        parts = normalized.split("/")
        if (not normalized or normalized.startswith("/") or
                any(part in ("", ".", "..") for part in parts) or
                re.match(r"^[A-Za-z]:", parts[0]) or
                re.search(r"[\x00-\x1f\x7f]", normalized)):
            raise ValueError("unsafe-archive-entry")
        if normalized in seen:
            raise ValueError("duplicate-archive-entry")
        seen.add(normalized)
        mode = (info.external_attr >> 16) & 0xFFFF
        kind = stat.S_IFMT(mode)
        if stat.S_ISLNK(mode) or (kind and kind not in (stat.S_IFREG, stat.S_IFDIR)):
            raise ValueError("archive-contains-a-link-or-special-file")
        if info.flag_bits & 0x1:
            raise ValueError("encrypted-archive-entry")
        if info.file_size < 0 or info.file_size > MAX_WORLD_FILE_BYTES:
            raise ValueError("archive-file-exceeds-size-limit")
        total_size += info.file_size
        if total_size > MAX_WORLD_ARCHIVE_BYTES:
            raise ValueError("archive-exceeds-size-limit")
        result.append((info, normalized, is_dir))
    return result


def _zip_safe(zf, base, members=None):
    members = _validated_zip_members(zf) if members is None else members
    base = os.path.abspath(base)
    if os.path.islink(base):
        raise ValueError("unsafe-extraction-root")
    os.makedirs(base, exist_ok=True)
    base_real = os.path.realpath(base)
    written = 0
    for info, relative, is_dir in members:
        target = os.path.abspath(os.path.join(base_real, *relative.split("/")))
        if target != base_real and not target.startswith(base_real + os.sep):
            raise ValueError("unsafe-archive-entry")
        if os.path.islink(target):
            raise ValueError("archive-destination-is-a-link")
        if is_dir:
            if os.path.lexists(target) and not os.path.isdir(target):
                raise ValueError("archive-file-directory-conflict")
            os.makedirs(target, exist_ok=True)
            continue
        parent = os.path.dirname(target)
        if os.path.lexists(parent) and (os.path.islink(parent) or not os.path.isdir(parent)):
            raise ValueError("archive-parent-is-not-a-directory")
        os.makedirs(parent, exist_ok=True)
        if os.path.lexists(target):
            raise ValueError("duplicate-archive-destination")
        actual_size = 0
        with zf.open(info, "r") as source, open(target, "xb") as destination:
            for block in iter(lambda: source.read(1024 * 1024), b""):
                actual_size += len(block)
                written += len(block)
                if actual_size > MAX_WORLD_FILE_BYTES or written > MAX_WORLD_ARCHIVE_BYTES:
                    raise ValueError("archive-exceeds-size-limit")
                destination.write(block)
        if actual_size != info.file_size:
            raise ValueError("archive-entry-size-mismatch")


def _read_pack_manifest(path):
    if os.path.isdir(path):
        manifest_path = os.path.join(path, "manifest.json")
        with open(manifest_path, "r", encoding="utf-8") as handle_file:
            data = json.load(handle_file)
        return _pack_info(data, path)
    with zipfile.ZipFile(path) as zf:
        names = zf.namelist()
        manifest_name = None
        for candidate in names:
            normalized = candidate.replace("\\", "/")
            if normalized.endswith("manifest.json") and normalized.count("/") <= 1:
                manifest_name = candidate
                break
        if manifest_name is None:
            raise ValueError("missing-manifest")
        raw = zf.read(manifest_name).decode("utf-8", "replace")
        return _pack_info(json.loads(raw), path)


def _pack_info(data, path):
    header = data.get("header") or {}
    modules = data.get("modules") or []
    kinds = {m.get("type") for m in modules if isinstance(m, dict)}
    if "data" in kinds:
        kind = "behavior"
    elif "resources" in kinds:
        kind = "resource"
    elif "script" in kinds:
        kind = "behavior"
    else:
        raise ValueError("unknown-pack-type")
    version = header.get("version") or [1, 0, 0]
    if isinstance(version, str):
        version = [int(x) for x in version.split(".") if x.isdigit()] or [1, 0, 0]
    return {
        "uuid": str(header.get("uuid") or ""),
        "name": str(header.get("name") or os.path.basename(path)),
        "version": version,
        "kind": kind,
    }


def apply_addons(data_root, addons_dir, state_path):
    """Install enabled packs and register them on the world.

    Toggles in the app write `enabled`, and this function is what makes that
    change real: it extracts the pack and rewrites world_behavior_packs.json /
    world_resource_packs.json for the selected world. `.mcaddon` bundles are
    expanded into their individual packs first.
    """
    result = {"ok": True, "installed": [], "skipped": []}
    try:
        with open(state_path, "r", encoding="utf-8") as handle_file:
            state = json.load(handle_file)
    except (OSError, ValueError):
        return {"ok": True, "installed": [], "skipped": [], "note": "no-addon-state"}
    world = state.get("world") or "Bedrock level"
    if "/" in world or "\\" in world or world in (".", ".."):
        world = "Bedrock level"
    level = safe_path(data_root, os.path.join("worlds", world))
    active = {"behavior": [], "resource": []}
    staging = os.path.join(addons_dir, ".staging")
    shutil.rmtree(staging, ignore_errors=True)
    for pack in state.get("packs") or []:
        if not isinstance(pack, dict):
            continue
        rel = pack.get("file") or ""
        src = os.path.join(addons_dir, os.path.basename(rel))
        if not os.path.isfile(src):
            result["skipped"].append({"file": rel, "reason": "missing-file"})
            continue
        enabled = bool(pack.get("enabled", True))
        sources = []
        if src.lower().endswith(".mcaddon"):
            bundle_dir = os.path.join(staging, os.path.splitext(os.path.basename(src))[0])
            try:
                with zipfile.ZipFile(src) as zf:
                    _zip_safe(zf, bundle_dir)
            except (ValueError, zipfile.BadZipFile) as error:
                result["skipped"].append({"file": rel, "reason": str(error)})
                continue
            for dirpath, _dirnames, filenames in os.walk(bundle_dir):
                if "manifest.json" in filenames:
                    sources.append(dirpath)
        else:
            sources.append(src)
        if not sources:
            result["skipped"].append({"file": rel, "reason": "no-pack-inside"})
            continue
        for source in sources:
            try:
                info = _read_pack_manifest(source)
            except (ValueError, zipfile.BadZipFile, json.JSONDecodeError) as error:
                result["skipped"].append({"file": rel, "reason": str(error)})
                continue
            folder = info["kind"] + "_packs"
            stem = os.path.splitext(os.path.basename(src))[0]
            if len(sources) > 1:
                stem = "%s-%s" % (stem, info["uuid"][:8])
            dest = safe_path(data_root, os.path.join(folder, stem))
            if enabled:
                shutil.rmtree(dest, ignore_errors=True)
                os.makedirs(dest, exist_ok=True)
                try:
                    if os.path.isdir(source):
                        if os.path.exists(dest):
                            shutil.rmtree(dest)
                        shutil.copytree(source, dest)
                    else:
                        with zipfile.ZipFile(source) as zf:
                            _zip_safe(zf, dest)
                except (ValueError, zipfile.BadZipFile, OSError) as error:
                    result["skipped"].append({"file": rel, "reason": str(error)})
                    continue
                active[info["kind"]].append({"pack_id": info["uuid"], "version": info["version"]})
                result["installed"].append({"file": rel, "kind": info["kind"], "uuid": info["uuid"], "name": info["name"]})
            else:
                shutil.rmtree(dest, ignore_errors=True)
                result["installed"].append({"file": rel, "kind": info["kind"], "uuid": info["uuid"], "name": info["name"], "disabled": True})
    shutil.rmtree(staging, ignore_errors=True)
    if os.path.isdir(level):
        for kind, entries in active.items():
            path = os.path.join(level, "world_%s_packs.json" % kind)
            with open(path, "w", encoding="utf-8") as handle_file:
                json.dump(entries, handle_file, indent=2)
    else:
        result["note"] = "world-not-generated-yet"
    result["world"] = world
    result["enabledCount"] = len(active["behavior"]) + len(active["resource"])
    return result


def _select_world_members(members, edition):
    roots = {}
    for info, relative, is_dir in members:
        if is_dir or relative.rsplit("/", 1)[-1] != "level.dat":
            continue
        root = relative.rsplit("/", 1)[0] if "/" in relative else ""
        roots.setdefault(root, {"has_level": True, "has_db": False})
    if not roots:
        raise ValueError("missing-level-dat")

    for root, state in roots.items():
        prefix = root + "/" if root else ""
        for _info, relative, is_dir in members:
            if is_dir or not relative.startswith(prefix):
                continue
            child = relative[len(prefix):]
            if child.startswith("db/"):
                state["has_db"] = True

    edition = str(edition or "").upper()
    if edition not in ("JAVA", "BEDROCK"):
        raise ValueError("unsupported-world-edition")
    if edition == "BEDROCK":
        candidates = [root for root, state in roots.items() if state["has_db"]]
        if not candidates:
            raise ValueError("missing-world-db")
    else:
        candidates = list(roots)
    if len(candidates) > 1:
        preferred = [root for root in candidates if root.rsplit("/", 1)[-1].casefold() == "world"]
        if len(preferred) == 1:
            candidates = preferred
    if len(candidates) != 1:
        raise ValueError("ambiguous-world-root")

    root = candidates[0]
    prefix = root + "/" if root else ""
    selected = []
    for info, relative, is_dir in members:
        if root:
            if relative == root and is_dir:
                continue
            if not relative.startswith(prefix):
                continue
            relative = relative[len(prefix):]
        if relative:
            selected.append((info, relative, is_dir))
    if not any(not is_dir and relative == "level.dat" for _info, relative, is_dir in selected):
        raise ValueError("missing-level-dat")
    return root, selected


def import_world(data_root, archive, name, edition, dry_run=False):
    data_root = safe_data_root(data_root)
    if os.path.islink(archive) or not os.path.isfile(archive):
        return {"ok": False, "error": "archive-not-found"}
    if os.path.getsize(archive) > MAX_WORLD_ARCHIVE_BYTES:
        return {"ok": False, "error": "archive-exceeds-size-limit"}
    try:
        with zipfile.ZipFile(archive, "r") as zf:
            members = _validated_zip_members(zf)
            root, selected = _select_world_members(members, edition)
            bedrock = str(edition or "").upper() == "BEDROCK"
            if bedrock and not any(not is_dir and relative.startswith("db/")
                                   for _info, relative, is_dir in selected):
                raise ValueError("missing-world-db")
            target_rel = os.path.join("worlds", name) if bedrock else name
            if name != ("Bedrock level" if bedrock else "world"):
                raise ValueError("unexpected-active-world-name")
            target = _no_symlink_components(data_root, target_rel)
            if os.path.lexists(target) and (os.path.islink(target) or not os.path.isdir(target)):
                raise ValueError("active-world-path-is-unsafe")
            parent = os.path.dirname(target)
            if os.path.lexists(parent) and (os.path.islink(parent) or not os.path.isdir(parent)):
                raise ValueError("active-world-parent-is-unsafe")
            stage_root = safe_path(data_root, ".nova-import-stage")
            if os.path.lexists(stage_root) and (os.path.islink(stage_root) or not os.path.isdir(stage_root)):
                raise ValueError("import-staging-path-is-unsafe")
            result = {
                "ok": True,
                "world": name,
                "edition": str(edition).upper(),
                "path": "worlds/" + name if bedrock else name,
                "archiveRoot": root,
            }
            if dry_run:
                return result
            os.makedirs(parent, exist_ok=True)
            os.makedirs(stage_root, mode=0o700, exist_ok=True)
            stage = tempfile.mkdtemp(prefix="world-", dir=stage_root)
            extracted = os.path.join(stage, "new-world")
            previous = os.path.join(stage, "previous-world")
            os.makedirs(extracted, mode=0o700)
            try:
                _zip_safe(zf, extracted, selected)
                if not os.path.isfile(os.path.join(extracted, "level.dat")):
                    raise ValueError("missing-level-dat")
                if bedrock and not any(os.path.isfile(os.path.join(extracted, "db", name))
                                       for name in os.listdir(os.path.join(extracted, "db"))):
                    raise ValueError("missing-world-db")
                moved_old = False
                if os.path.lexists(target):
                    os.replace(target, previous)
                    moved_old = True
                try:
                    os.replace(extracted, target)
                except Exception:
                    if moved_old and os.path.lexists(previous):
                        os.replace(previous, target)
                    raise
                if moved_old:
                    shutil.rmtree(previous)
            finally:
                shutil.rmtree(stage, ignore_errors=True)
    except (ValueError, OSError, zipfile.BadZipFile, RuntimeError, EOFError) as error:
        detail = str(error)[:180] or "invalid-world-archive"
        return {"ok": False, "error": detail}
    return result


TEXT_EXT = {
    ".txt", ".properties", ".json", ".yml", ".yaml", ".toml", ".cfg", ".conf", ".ini",
    ".log", ".md", ".sh", ".bat", ".xml", ".csv", ".mcmeta", ".snbt", ".list",
}
SNAPSHOT_LIMIT = 64 * 1024
SNAPSHOT_MAX_FILES = 150
SNAPSHOT_MAX_BYTES = 3 * 1024 * 1024


def snapshot(root, out_path):
    """Publish small, editable text files as one JSON document.

    This is what makes "edit while the server is stopped" honest: the runner
    publishes the current contents, the app edits the JSON, and the runner
    re-applies it on top of the restored cache before the next start.
    """
    root_real = safe_data_root(root)
    files = {}
    total = 0
    truncated = False
    for dirpath, dirnames, filenames in os.walk(root_real, followlinks=False):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not os.path.islink(os.path.join(dirpath, d))]
        for name in sorted(filenames):
            full = os.path.join(dirpath, name)
            if os.path.islink(full):
                continue
            ext = os.path.splitext(name)[1].lower()
            if ext not in TEXT_EXT:
                continue
            try:
                size = os.path.getsize(full)
            except OSError:
                continue
            if size > SNAPSHOT_LIMIT or size == 0:
                continue
            if total + size > SNAPSHOT_MAX_BYTES or len(files) >= SNAPSHOT_MAX_FILES:
                truncated = True
                break
            rel = os.path.relpath(full, root_real).replace(os.sep, "/")
            try:
                with open(full, "rb") as handle_file:
                    files[rel] = base64.b64encode(handle_file.read()).decode()
            except OSError:
                continue
            total += size
        if truncated:
            break
    payload = {
        "schema": 1,
        "generatedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "truncated": truncated,
        "files": files,
    }
    atomic_write_json(out_path, payload)
    return payload


def apply_snapshot(root, snap_path):
    """Apply repository-side edits on top of the restored cache."""
    try:
        with open(snap_path, "r", encoding="utf-8") as handle_file:
            payload = json.load(handle_file)
    except (OSError, ValueError):
        return {"ok": True, "applied": 0}
    applied = 0
    for rel, encoded in (payload.get("files") or {}).items():
        dest = safe_path(root, rel)
        os.makedirs(os.path.dirname(dest) or os.path.realpath(root), exist_ok=True)
        atomic_write_bytes(dest, base64.b64decode(encoded))
        applied += 1
    return {"ok": True, "applied": applied}


def _is_safe_jar_relpath(value):
    if not isinstance(value, str) or value != value.strip() or "\\" in value or len(value) > 240:
        return False
    parts = value.split("/")
    if any(part in ("", ".", "..") or len(part) > 128 or re.search(r"[\x00-\x1f\x7f]", part) for part in parts):
        return False
    return len(parts) >= 2 and parts[0] in ("mods", "plugins") and parts[-1].lower().endswith(".jar")


def _blob_sha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\x00" + data).hexdigest()


def _no_symlink_components(root, rel):
    current = os.path.realpath(root)
    for part in rel.split("/"):
        current = os.path.join(current, part)
        if os.path.islink(current):
            raise ValueError("managed JAR path contains a symlink")
    return current


def _tracked_jar_blobs(repo_root, data_rel, folders):
    tracked = {}
    for folder in folders:
        repo_dir = "%s/%s" % (data_rel, folder)
        result = subprocess.run(
            ["git", "-C", repo_root, "ls-tree", "-r", "-z", "--full-tree", "HEAD", "--", repo_dir],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=False,
        )
        if result.returncode != 0:
            raise RuntimeError("git ls-tree failed for %s" % repo_dir)
        for row in result.stdout.split(b"\x00"):
            if not row:
                continue
            try:
                metadata, path_bytes = row.split(b"\t", 1)
                mode, kind, object_sha = metadata.decode("ascii").split(" ", 2)
                path = path_bytes.decode("utf-8")
            except (ValueError, UnicodeDecodeError):
                raise ValueError("invalid tracked JAR tree entry")
            prefix = repo_dir + "/"
            if kind != "blob" or mode not in ("100644", "100755") or not path.startswith(prefix):
                continue
            relative = path[len(data_rel) + 1:]
            if not relative.lower().endswith(".jar"):
                continue
            if not _is_safe_jar_relpath(relative) or not re.fullmatch(r"[0-9a-fA-F]{40}", object_sha):
                raise ValueError("unsafe tracked JAR path or object id")
            if relative in tracked:
                raise ValueError("duplicate tracked JAR path")
            tracked[relative] = object_sha.lower()
            if len(tracked) > MAX_MANAGED_JARS:
                raise ValueError("too many tracked managed JARs")
    return tracked


def _git_blob_bytes(repo_root, object_sha):
    result = subprocess.run(
        ["git", "-C", repo_root, "cat-file", "blob", object_sha],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError("git could not read a managed JAR blob")
    if not result.stdout or len(result.stdout) > MAX_MANAGED_JAR_BYTES:
        raise ValueError("managed JAR is empty or exceeds the supported GitHub file size")
    if _blob_sha(result.stdout) != object_sha:
        raise ValueError("managed JAR blob hash did not match Git")
    return result.stdout


def _file_blob_sha(path):
    digest = hashlib.sha1()
    size = os.path.getsize(path)
    digest.update(b"blob " + str(size).encode("ascii") + b"\x00")
    with open(path, "rb") as handle_file:
        for block in iter(lambda: handle_file.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sync_managed_jars(root, repo_root, data_rel, software):
    """Make the runner's actual mods/plugins folder match tracked GitHub JARs.

    This runs after the Actions cache restore: cache contents never override the
    current repository's HEAD blobs. Only JARs recorded by NOVA CRAFT's prior
    sync are pruned, and a failed update is rolled back before returning.
    """
    software = str(software or "").upper()
    if software == "FABRIC":
        folders = ["mods"]
    elif software in ("PAPER", "PURPUR", "SPIGOT"):
        folders = ["plugins"]
    else:
        return {"ok": True, "status": "not_applicable", "installed": [], "removed": [], "files": {}}

    root_real = safe_data_root(root)
    repo_real = os.path.realpath(repo_root)
    if not os.path.isdir(repo_real) or not os.path.isdir(os.path.join(repo_real, ".git")):
        raise ValueError("repository checkout is unavailable for managed JAR sync")
    data_rel = str(data_rel or "").replace("\\", "/")
    if (not data_rel or data_rel.startswith("/") or
            any(part in ("", ".", "..") for part in data_rel.split("/"))):
        raise ValueError("unsafe repository data path for managed JAR sync")
    expected_root = os.path.realpath(os.path.join(repo_real, *data_rel.split("/")))
    if expected_root != root_real:
        raise ValueError("managed JAR data path does not match the runner data root")

    tracked = _tracked_jar_blobs(repo_real, data_rel, folders)
    managed_dir = safe_path(root_real, ".nova-managed")
    if os.path.lexists(managed_dir) and (os.path.islink(managed_dir) or not os.path.isdir(managed_dir)):
        raise ValueError("managed JAR state path is unsafe")
    os.makedirs(managed_dir, mode=0o700, exist_ok=True)
    state_path = os.path.join(managed_dir, "jars.json")
    if os.path.islink(state_path):
        raise ValueError("managed JAR state file is a symlink")
    previous = {}
    try:
        with open(state_path, "r", encoding="utf-8") as handle_file:
            saved = json.load(handle_file)
        if saved.get("schema") == 1 and isinstance(saved.get("files"), dict):
            for rel, object_sha in saved["files"].items():
                if (_is_safe_jar_relpath(rel) and isinstance(object_sha, str) and
                        re.fullmatch(r"[0-9a-fA-F]{40}", object_sha) and len(previous) < MAX_MANAGED_JARS):
                    previous[rel] = object_sha.lower()
    except (OSError, ValueError, AttributeError):
        previous = {}

    stage = os.path.join(managed_dir, "staging")
    if os.path.lexists(stage):
        if os.path.islink(stage) or not os.path.isdir(stage):
            raise ValueError("managed JAR staging path is unsafe")
        shutil.rmtree(stage)
    os.makedirs(os.path.join(stage, "new"), mode=0o700)
    os.makedirs(os.path.join(stage, "previous"), mode=0o700)

    installed = []
    removed = []
    moved_old = []
    installed_new = []
    active_prefixes = tuple(folder + "/" for folder in folders)
    managed_next = {rel: sha for rel, sha in previous.items() if not rel.startswith(active_prefixes)}
    try:
        # Fetch, verify and stage every current JAR before touching live files.
        for rel, object_sha in sorted(tracked.items()):
            data = _git_blob_bytes(repo_real, object_sha)
            stage_path = os.path.join(stage, "new", *rel.split("/"))
            os.makedirs(os.path.dirname(stage_path), exist_ok=True)
            with open(stage_path, "xb") as handle_file:
                handle_file.write(data)

        stale = {rel: sha for rel, sha in previous.items()
                 if rel.startswith(active_prefixes) and rel not in tracked}
        all_targets = set(tracked) | set(stale)
        for rel in all_targets:
            target = _no_symlink_components(root_real, rel)
            if os.path.lexists(target) and (os.path.islink(target) or not os.path.isfile(target)):
                raise ValueError("managed JAR destination is not a regular file")

        # Replace current files atomically and retain originals in the staging
        # directory until the state marker has been written successfully.
        for rel, object_sha in sorted(tracked.items()):
            target = _no_symlink_components(root_real, rel)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            if os.path.isfile(target) and _file_blob_sha(target) == object_sha:
                managed_next[rel] = object_sha
                continue
            staged = os.path.join(stage, "new", *rel.split("/"))
            if os.path.lexists(target):
                previous_path = os.path.join(stage, "previous", *rel.split("/"))
                os.makedirs(os.path.dirname(previous_path), exist_ok=True)
                os.replace(target, previous_path)
                moved_old.append((target, previous_path))
            os.replace(staged, target)
            installed_new.append(target)
            installed.append(rel)
            managed_next[rel] = object_sha

        # Do not delete files that a user changed after NOVA CRAFT last synced.
        for rel, old_sha in sorted(stale.items()):
            target = _no_symlink_components(root_real, rel)
            if not os.path.isfile(target) or _file_blob_sha(target) != old_sha:
                continue
            previous_path = os.path.join(stage, "previous", *rel.split("/"))
            os.makedirs(os.path.dirname(previous_path), exist_ok=True)
            os.replace(target, previous_path)
            moved_old.append((target, previous_path))
            removed.append(rel)

        atomic_write_json(state_path, {"schema": 1, "files": managed_next})
    except Exception:
        for target in reversed(installed_new):
            if os.path.lexists(target) and not os.path.islink(target):
                os.unlink(target)
        for target, previous_path in reversed(moved_old):
            if os.path.lexists(previous_path):
                os.makedirs(os.path.dirname(target), exist_ok=True)
                os.replace(previous_path, target)
        raise
    finally:
        if os.path.isdir(stage) and not os.path.islink(stage):
            shutil.rmtree(stage, ignore_errors=True)

    return {
        "ok": True,
        "status": "synced",
        "installed": installed,
        "removed": removed,
        "files": managed_next,
    }


def main(argv):
    if len(argv) < 3:
        print("usage: fileops.py <mode> ...", file=sys.stderr)
        return 2
    mode = argv[1]
    if mode == "manifest":
        root, out = argv[2], argv[3]
        root = safe_data_root(root)
        data = manifest(root)
        atomic_write_json(out, data)
        print("manifest %d files" % len(data["files"]))
        return 0
    if mode == "request":
        root, request_path, response_path = argv[2], argv[3], argv[4]
        root = safe_data_root(root)
        try:
            with open(request_path, "r", encoding="utf-8") as handle_file:
                request = json.load(handle_file)
        except (OSError, ValueError):
            request = {}
        request_id = request.get("id")
        try:
            response = handle(root, request)
        except ValueError as error:
            response = _fail(str(error))
        except OSError as error:
            response = _fail("os-error: %s" % error.strerror)
        response["id"] = request_id
        with open(response_path, "w", encoding="utf-8") as handle_file:
            json.dump(response, handle_file, separators=(",", ":"))
        print("request %s -> ok=%s" % (request.get("op"), response.get("ok")))
        return 0
    if mode == "addons":
        data_root, addons_dir, state_path, out = argv[2], argv[3], argv[4], argv[5]
        result = apply_addons(data_root, addons_dir, state_path)
        with open(out, "w", encoding="utf-8") as handle_file:
            json.dump(result, handle_file, separators=(",", ":"))
        print("addons installed=%d skipped=%d" % (len(result["installed"]), len(result["skipped"])))
        return 0
    if mode == "snapshot":
        root, out_path = argv[2], argv[3]
        result = snapshot(root, out_path)
        print("snapshot %d files" % len(result["files"]))
        return 0
    if mode == "apply-snapshot":
        root, snap_path = argv[2], argv[3]
        print("apply-snapshot", apply_snapshot(root, snap_path))
        return 0
    if mode == "validate-import":
        if len(argv) < 7:
            print("usage: fileops.py validate-import <data_root> <zip> <world_name> <out.json> <JAVA|BEDROCK>", file=sys.stderr)
            return 2
        data_root, archive, name, out, edition = argv[2], argv[3], argv[4], argv[5], argv[6]
        try:
            result = import_world(data_root, archive, name, edition, dry_run=True)
        except (ValueError, OSError) as error:
            result = {"ok": False, "error": str(error)[:180] or "invalid-world-archive"}
        atomic_write_json(out, result)
        print("world import preflight ok=%s" % result.get("ok"))
        return 0 if result.get("ok") else 1
    if mode == "import":
        if len(argv) < 7:
            print("usage: fileops.py import <data_root> <zip> <world_name> <out.json> <JAVA|BEDROCK>", file=sys.stderr)
            return 2
        data_root, archive, name, out, edition = argv[2], argv[3], argv[4], argv[5], argv[6]
        try:
            result = import_world(data_root, archive, name, edition)
        except (ValueError, OSError) as error:
            result = {"ok": False, "error": str(error)[:180] or "import-failed"}
        atomic_write_json(out, result)
        print("import -> %s" % result)
        return 0 if result.get("ok") else 1
    if mode == "sync-jars":
        if len(argv) < 7:
            print("usage: fileops.py sync-jars <data_root> <repo_root> <data_rel> <software> <out.json>", file=sys.stderr)
            return 2
        data_root, repo_root, data_rel, software, out = argv[2], argv[3], argv[4], argv[5], argv[6]
        try:
            result = sync_managed_jars(data_root, repo_root, data_rel, software)
        except Exception as error:
            result = {"ok": False, "status": "failed", "error": str(error)[:240] or "managed-jar-sync-failed"}
            atomic_write_json(out, result)
            print("managed JAR sync failed: %s" % result["error"], file=sys.stderr)
            return 1
        atomic_write_json(out, result)
        print("managed JAR sync status=%s installed=%d removed=%d" % (
            result.get("status", "unknown"), len(result.get("installed", [])), len(result.get("removed", []))))
        return 0 if result.get("ok") else 1
    print("unknown mode", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
