# مولّدات سيرفر NOVA CRAFT (نسخ مستقلة للفحص)

هذه الملفات استُخرجت مباشرةً من السلاسل الخام في `source/lib/core/workflow_templates.dart` عند الالتزام `b3bf132d9a087d7f625d9564c1600d07258b0553`، دون تعديل منطقها. يقوم `Provisioner.writeServerFiles` برفع سكربتات التشغيل إلى مستودع السيرفر.

- `nova-craft/config.py` من `WorkflowTemplates.configScript`
- `nova-craft/runner.sh` من `WorkflowTemplates.runnerScript`
- `nova-craft/playit.py` من `WorkflowTemplates.playitScript`
- `nova-craft/fileops.py` من `WorkflowTemplates.fileOpsScript`
- `.github/workflows/novacraft-server.yml` من `_serverWorkflow`؛ استُبدل الرمز `__SID__` بقيمة توضيحية `example-server-id` فقط. التطبيق يستبدله بمعرّف السيرفر الحقيقي عند التهيئة.

هذه **ليست نسخة إعدادات مستخدم**: لم يُرفق `server.json` أو أسرار أو عوالم أو ملفات تشغيل ناتجة. راجع `../docs/SAFE_DEVELOPMENT.md` قبل تجربة أي workflow؛ تشغيله في مستودع حقيقي ينفّذ Minecraft وPlayit ويستهلك دقائق Actions وقد ينشئ Releases.
