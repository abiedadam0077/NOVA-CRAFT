# البناء والاختبارات والتحقق

## البيئة المعلنة في المصدر

- قيد Dart في `pubspec.yaml`: `>=3.5.0 <4.0.0`.
- CI في `.github/workflows/flutter.yml` يحدد Flutter `3.35.7` وJava 17، ويطلب Android SDK platform 36.
- Gradle wrapper `8.14`، Android Gradle Plugin `8.9.1`، Kotlin `2.1.0`، `compileSdk=36`، و`targetSdk=35`.
- `pubspec.yaml` يطلب Flutter و`http ^1.2.2` و`shared_preferences ^2.3.3` و`flutter_secure_storage ^9.2.2` و`url_launcher ^6.3.1` و`file_picker ^8.1.6` و`archive ^3.6.1` و`pinenacl ^0.6.0`، إضافة إلى `flutter_test` و`flutter_lints ^5.0.0`.
- لا يوجد `pubspec.lock` في مجموعة الملفات المنقولة من هذا الالتزام.

## مسارات CI الموجودة في الشيفرة

Workflow التطبيق يعرّف `flutter pub get` ثم `flutter analyze` و`flutter test --reporter expanded`، ثم بناء APK وتسليمه عند تشغيله على push مطابقة أو يدوياً. Workflow `android-smoke.yml` يدوي فقط ويحمّل APK منشوراً سابقاً لاختباره؛ لا يبني التطبيق. وجود هذه الخطوات في المصدر **لا يعني أنها نُفذت أثناء إعداد الحزمة**؛ لم يُشغّل أي منهما. دفع الحزمة الجديدة يقتصر على `docs/downloads/`، وهو ضمن `paths-ignore: [README.md, docs/**]` في workflow التطبيق.

## فحوص هذه الحزمة

- تم التحقق من أن ملفات `source/` تطابق blobs في الالتزام المحدد، لا ملفات شجرة العمل الحالية.
- تم استخراج القوالب الخمسة من `workflow_templates.dart` ومطابقة محتواها مع أجسام السلاسل الخام.
- تم فحص سلامة ZIP والبصمات الداخلية والخارجية.
- تم إجراء فحص نحوي ثابت لـ`runner.sh` بـ`bash -n` ولملفات Python المستخرجة عبر `ast.parse`؛ لا يشغّل هذا الفحص الخادم ولا يتصل بـPlayit أو GitHub.

**لم يتم تشغيل `flutter analyze` أو `flutter test`، ولم يتم تشغيل أي اختبار Dart/Flutter، ولم يُبنَ APK أو تطبيق.** أدوات Flutter/Dart غير متاحة في بيئة إعداد هذه الحزمة. الاختبارات الموجودة وعددها 15 موثقة في `TEST_INVENTORY.md`.

## تشغيل اختبارات المصدر لاحقاً

من داخل `source/`، على بيئة مناسبة وبالنسخة المتوافقة من Flutter:

```sh
flutter pub get
flutter analyze
flutter test --reporter expanded
```

هذه أوامر توثيقية فقط؛ لم تُنفذ في هذه المهمة.