# قوالب التشغيل المستخرجة

تُنشئ `Provisioner.writeServerFiles` في المصدر ملفات تشغيل داخل مستودع السيرفر ضمن `nova-craft/` و`.github/workflows/`. الملفات الخمسة التالية نُسخت من أجسام السلاسل الخام في `WorkflowTemplates` عند الالتزام المرجعي، لا من ملفات تشغيل أحدث:

| الملف داخل الحزمة | رمز المصدر | الحجم المستخرج بالبايت |
|---|---|---:|
| `runtime-templates/.github/workflows/novacraft-server.yml` | `_serverWorkflow` | 1,832 |
| `runtime-templates/nova-craft/config.py` | `configScript` | 5,103 |
| `runtime-templates/nova-craft/runner.sh` | `runnerScript` | 69,961 |
| `runtime-templates/nova-craft/playit.py` | `playitScript` | 10,502 |
| `runtime-templates/nova-craft/fileops.py` | `fileOpsScript` | 19,550 |

## ما يفعله كل قالب وفق النص المرجعي

- **`novacraft-server.yml`**: workflow يدوي بخيارَي `start` و`snapshot`، وإدخال اختياري `restore_tag`. يستخدم Ubuntu 24.04، إعداد Java عند الحاجة، Actions cache، والمهلة القصوى للمهمة 360 دقيقة. النص المصدّر يحتفظ بـ`__SID__` كما في المصدر؛ الدالة `serverWorkflow(serverId)` تستبدله بمعرّف السيرفر عند الإنشاء.
- **`config.py`**: يقرأ `nova-craft/server.json`، يتحقق من مسارات البيانات ومعرّف السيرفر والقيم، ثم يكتب GitHub step outputs للاستخدام في workflow. لا يطبع مفتاح Playit.
- **`runner.sh`**: دورة الخادم على runner مستضاف لدى GitHub: استعادة البيانات/النسخة المحددة، تنزيل ملف السيرفر والتحقق من بصمته وفق الإعداد، تشغيله، نشر الحالة والسجل والـmanifest، استهلاك أوامر التطبيق وطلبات الملفات، إنشاء نسخة العالم والتحقق منها، ثم إيقاف الدورة أو إرسال دورة جديدة بحسب الإعداد.
- **`playit.py`**: يحلل rundata ويختار نفقاً مناسباً موجوداً، أو نفقاً معيّناً، ويفحص وصول Minecraft على العنوان. لا ينشئ الأنفاق ولا يطبع السر.
- **`fileops.py`**: يحصر عمليات الملفات داخل جذر بيانات السيرفر ويرفض اجتياز المسار أو الخروج عبر symlink. يدعم إنشاء manifest، وطلبات list/read/write/mkdir/rename/delete، واستيراد العالم، وحزم Bedrock، ولقطة إعدادات قابلة للتطبيق. حد القراءة في هذا الإصدار 700 KiB، والـmanifest حتى 4,000 مدخل، ولقطة الإعداد حتى 150 ملفاً/3 MiB.

## التحقق من المطابقة

حُفظت أجسام السلاسل الخام من `source/lib/core/workflow_templates.dart` كما هي، بما فيها الأسطر الفارغة الأولى إن وجدت. لا تُعد الملفات المصدّرة بديلاً عن ملف Dart؛ الملف الأصلي الكامل باقٍ في `source/`. البصمات الداخلية تغطي ملفات التصدير أيضاً.

قوالب Java وBedrock لـ`server.properties` تُنشأ بواسطة دالتَي `javaProperties(ServerConfig)` و`bedrockProperties(ServerConfig)` في ملف Dart، وتعتمدان على إعدادات السيرفر. لم تُحوّل إلى ملفات ثابتة بقيم افتراضية حتى لا يُنسب للمصدر قالب مختلف.