# جرد ملفات الاختبار عند الالتزام المرجعي

يوجد **15 ملف اختبار** تحت `source/test/` في الالتزام `070385b75acc8abd3c7023ab9d74ff8dd7695bf4`:

1. `fileops_integration_test.dart`
2. `files_screen_test.dart`
3. `formatters_test.dart`
4. `github_api_test.dart`
5. `minecraft_test.dart`
6. `models_test.dart`
7. `modrinth_test.dart`
8. `playit_api_test.dart`
9. `playit_runner_integration_test.dart`
10. `playit_runner_test.dart`
11. `runner_contract_test.dart`
12. `scripts_contract_test.dart`
13. `strings_test.dart`
14. `validation_test.dart`
15. `widget_test.dart`

الملفات المسماة `*_integration_test.dart` وملفات `*_contract_test.dart` تفحص عقود المساعدات/الـrunner أو تكاملها كما يحددها المصدر؛ بقية الملفات تغطي وحدات التطبيق وواجهة المستخدم. من أمثلة الحالات الظاهرة في `fileops_integration_test.dart`: إنشاء manifest، عكس عمليات الملفات في القائمة، رفض traversal وsymlink escape، وتطبيق snapshot آمن. ويختبر `scripts_contract_test.dart` عقود ملفات التشغيل، بما فيها Bedrock add-ons وPlayit والنسخ ودورة التشغيل.

هذه قائمة **بملفات موجودة** وليست تقرير نجاح. لم تُشغّل هذه الاختبارات أثناء إعداد ZIP؛ راجع `BUILD_AND_VALIDATION.md`.