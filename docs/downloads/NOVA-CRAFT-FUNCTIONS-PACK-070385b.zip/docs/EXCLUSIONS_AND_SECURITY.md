# الاستبعادات وملاحظات الأمان

## ملفات وبيانات مستبعدة

لم تُنسخ ملفات البناء والتقارير التاريخية من جذر الالتزام، ومنها:

- `nova-craft-final.apk` (الملف الأصلي التاريخي حجمه 64,289,022 بايت)؛ لا يوجد APK داخل الحزمة.
- `build_log.txt`, `builds.json`, `paper.json`, `SHA256SUMS.txt`, `final_sha256.txt`, `sha256.txt`, `smoke-trigger.txt`.
- `NOVA_CRAFT_Complete_Development_Prompt_AR.md`.
- وثائق المستودع التاريخية: `docs/IMPLEMENTATION-STATUS-AR.md`, `docs/PHASE-01-RESEARCH-AND-GITHUB-APP-AR.md`, `docs/PHASE-A-AUDIT-AR.md`, `docs/PLAYIT-DIAGNOSTICS-AR.md`, `docs/REBUILD_REPORT.md`, `docs/REBUILD_REPORT_FINAL.md`.
- لم تكن ضمن مجموعة الملفات المنتقاة بيانات `server/` أو عوالم أو أرشيفات نسخ احتياطي. ولم تُدرج أي منها.

استُبعد README الأصلي للمستودع لأنه يتضمن روابط تاريخية إلى APK/إصدارات؛ README الموجود في جذر هذه الحزمة جديد وموسوم بأنه توثيق للحزمة.

## الأسرار

- لم يُعثر في أسماء الملفات المنتقاة على ملفات keystore/certificate/private-key أو ملفات إعداد أسرار مثل `.env` أو `key.properties`.
- فُحصت أنماط شائعة لمفاتيح GitHub/AWS والمفاتيح الخاصة في المسارات المنتقاة ولم يظهر تطابق. هذا فحص استبعادي محدود وليس تدقيقاً أمنياً شاملاً.
- `AppConfig` في المصدر يصرّح بأن معرّف GitHub OAuth وGitHub App ID معرفات عامة، لا client secret أو مفتاح خاص. كما تظهر أسماء متغيرات Secrets في workflow (`PLAYIT_SECRET_KEY` ومفاتيح توقيع CI)، لكن قيم الأسرار نفسها غير مضمّنة.
- لا توجد قيمة حقيقية لمفتاح Playit أو مفتاح توقيع في ملفات القوالب المصدّرة.

القوالب منقولة كما هي؛ هذا لا يجعل تشغيل workflow أو إدخال أسرار حقيقية آمناً تلقائياً. راجع المحتوى قبل استخدامه، ولا تضف أسراراً إلى ملفات المصدر.