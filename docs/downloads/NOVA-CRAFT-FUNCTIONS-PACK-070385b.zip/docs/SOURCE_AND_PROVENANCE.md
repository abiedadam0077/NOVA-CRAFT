# المصدر وسلسلة المنشأ

## الالتزام المرجعي

- **Commit:** `070385b75acc8abd3c7023ab9d74ff8dd7695bf4`
- **العنوان:** `Prepare fresh Android APK build`
- **التاريخ في Git:** 2026-10-19
- **ملف القوالب:** `source/lib/core/workflow_templates.dart`
- **Git blob لملف القوالب:** `a11e44e0eaa09a1a4076f7b478b7a37cf749f9af`

أُنشئ مجلد المصدر باستخدام `git archive` من هذا الالتزام نفسه، لا من `HEAD` المحلي ولا من الحزمة السابقة ولا من نسخة أحدث. جرى اختيار ملفات المشروع والكود والموارد والاختبارات وملفات Actions فقط. عدد الملفات المنقولة كما هي **133**:

| المسار الأصلي | العدد |
|---|---:|
| `.github/` | 2 |
| `.gitignore`, `.metadata`, `analysis_options.yaml`, `pubspec.yaml` | 4 |
| `android/` | 33 |
| `assets/` | 30 |
| `lib/` | 49 |
| `test/` | 15 |
| **الإجمالي** | **133** |

ملفا Actions الأصليان هما `.github/workflows/flutter.yml` و`.github/workflows/android-smoke.yml`. لم تُعدّل ملفات المصدر أو الاختبارات أو الـworkflow أثناء إعداد الحزمة.

## ما أُضيف للحزمة

هذه الملفات ليست من شجرة المشروع الأصلية؛ أُنشئت للتوثيق والتوزيع فقط:

- `README.md` وملفات `docs/*.md`.
- `SOURCE_FILE_MANIFEST.txt` الذي يسرد بصمات blobs للملفات الأصلية.
- `runtime-templates/`، وهي صادرات حرفية لخمس سلاسل تشغيل من `workflow_templates.dart`؛ راجع `RUNTIME_TEMPLATES.md`.
- `SHA256SUMS.txt` وبصمة ZIP الخارجية.

لم يُدرج `README.md` الأصلي للمستودع داخل `source/` لأنه يتضمن إحالات تاريخية إلى APK وإصدارات سابقة. كما لم تُنسخ وثائق `docs/` التاريخية من الالتزام؛ قائمة الملفات المستبعدة وسبب ذلك في `EXCLUSIONS_AND_SECURITY.md`. لذلك لا ينبغي الخلط بين وثائق الحزمة الجديدة والوثائق الموجودة في المستودع عند ذلك الالتزام.

## استخراج القوالب

استُخرجت أجسام السلاسل الخام كما هي، من دون قصّ الأسطر أو إعادة تنسيقها أو إصلاحها. المصدر الوحيد لها هو `source/lib/core/workflow_templates.dart`، والبصمات والحجوم موثقة في `RUNTIME_TEMPLATES.md`. ملف `.github/workflows/novacraft-server.yml` يحتفظ بالعنصر النائب الحرفي `__SID__`: دالة `WorkflowTemplates.serverWorkflow(serverId)` في المصدر هي التي تستبدله عند إنشاء workflow.

مولّدا `javaProperties` و`bedrockProperties` موجودان في ملف Dart الأصلي، لكنهما دالتان تعتمد مخرجاتهما على `ServerConfig` وليستا من سكربتات التشغيل الخمسة، لذلك لم يُنشأ لهما ملف قالب مصطنع.

## منع خلط الإصدارات

الحزمة لا تتضمن ملفات أضيفت بعد الالتزام المرجعي، ومن أمثلتها:

- `lib/core/cancellation.dart`
- `lib/core/modrinth_installer.dart`
- `lib/core/server_file_manifest.dart`
- `test/modrinth_installer_test.dart`
- `test/worlds_manifest_test.dart`

كما لا تُسقط الحزمة أي إصلاح لاحق على Geyser أو منطق تثبيت الإضافات. غياب أسماء الملفات هذه من شجرة المرجع جرى التحقق منه عند الالتزام المحدد. الحزمة السابقة المبنية من `b3bf132` ملف مستقل، ولم يُستبدل أو يُستخدم مصدراً لهذه الحزمة.

لإعادة استخراج مجموعة الملفات نفسها من مستودع يملك كائن الالتزام:

```sh
git archive --format=tar 070385b75acc8abd3c7023ab9d74ff8dd7695bf4 \
  .github .gitignore .metadata analysis_options.yaml pubspec.yaml android assets lib test
```