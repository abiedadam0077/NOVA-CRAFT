# NOVA CRAFT — حزمة مرجعية للالتزام `070385b`

هذه **نسخة ثانية مستقلة** مبنية من الالتزام الأصلي `070385b75acc8abd3c7023ab9d74ff8dd7695bf4` فقط، وليست إعادة استخدام للحزمة السابقة المبنية من `b3bf132`. لا تتضمن هذه الحزمة إصلاحات أو ملفات من التزامات أحدث، ولا تغيّر التطبيق أو الواجهة أو التنقّل.

## المحتويات

- `source/` — 133 ملفاً أصلياً من الالتزام المرجعي: مشروع Flutter/Android، الموارد، الاختبارات، وملفا GitHub Actions الأصليان. نُقلت هذه الملفات كما هي.
- `SOURCE_FILE_MANIFEST.txt` — مسار كل ملف أصلي مع Git mode وblob SHA-1 للتحقق من المنشأ.
- `runtime-templates/` — نصوص التشغيل الخمسة المستخرجة حرفياً من السلاسل المقابلة في `source/lib/core/workflow_templates.dart`. يحتفظ ملف الـworkflow بالعنصر النائب الأصلي `__SID__`؛ التطبيق يستبدله فقط عند إنشاء workflow لسيرفر محدد.
- `docs/` — توثيق جديد يشرح أصل الملفات، وظائفها وحدودها، الاختبارات، والاستبعادات.
- `SHA256SUMS.txt` — بصمات SHA-256 لملفات الحزمة الداخلية (باستثناء ملف البصمات نفسه).

## التنزيل والتحقق

- [تنزيل ZIP من GitHub](https://raw.githubusercontent.com/abiedadam0077/NOVA-CRAFT/arena/9027d464-nova-craft/docs/downloads/NOVA-CRAFT-FUNCTIONS-PACK-070385b.zip)
- [ملف SHA-256 على GitHub](https://raw.githubusercontent.com/abiedadam0077/NOVA-CRAFT/arena/9027d464-nova-craft/docs/downloads/NOVA-CRAFT-FUNCTIONS-PACK-070385b.zip.sha256)

بعد فك الضغط، من جذر الحزمة:

```sh
sha256sum -c SHA256SUMS.txt
```

## النطاق بوضوح

هذه أرشفة للمصدر الموجود في الالتزام المرجعي ووثائق تفسيرية مضافة؛ **ليست APK، ولا بناءً جديداً، ولا خادماً جاهزاً للتشغيل**. لا تضم APK أو عوالم أو نسخاً احتياطية أو سجلات بناء تاريخية أو مفاتيح توقيع. لم يُشغّل Flutter/Dart أو اختبارات التطبيق في إعداد هذه الحزمة؛ نتائج الفحص البنيوي موثقة في `docs/BUILD_AND_VALIDATION.md`.

ابدأ بـ`docs/SOURCE_AND_PROVENANCE.md` لمعرفة ما نُقل كما هو وما أُضيف، ثم راجع `docs/FEATURES_AND_LIMITS.md` و`docs/RUNTIME_TEMPLATES.md` لفهم السلوك كما كان في الالتزام المحدد، من دون إسقاط تغييرات لاحقة عليه.